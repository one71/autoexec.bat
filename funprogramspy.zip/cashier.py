a = float(input("Welcome to Popeye's! Enter the price of one item:"))
b = float(input("Enter the price of another item:"))
c = float(input("Enter the price of another item:"))
d = float(input("Enter the sales tax percentage of your area as a decimal:"))
w = (a + b + c)*d
x = round((a + b + c + w), 2)
y = float(input("Your total is $" + str(x) + ". How much will you pay?"))
z = round((y - x), 2)
o = x - y

if y >= x:
    print("Your total is $" + str(x) + " plus tax.")
    print("You paid $" + str(y) + ".")
    print("Your change is $" + str(z) + ".")
    print("Have a nice day!")
else:
    n = input("You still owe $" + str(o) + ". Can you pay the rest? (Yes or no?)")
    if n == "yes" or n == "Yes":
        print("Thank you. Have a nice day!")
    else:
        print("Sorry, you will have to void some items.")