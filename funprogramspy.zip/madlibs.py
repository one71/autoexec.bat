print("Let's do a MadLibs!")

item1 = input("Enter a noun:")
item2 = input("Enter a noun:")
item3 = input("Enter a noun:")
item4 = input("Enter a noun:")
item5 = input("Enter a noun:")

print("\nI heard that you ate " + item1 + " for breakfast this morning.\n\nI heard that you accompanied your meal with " + item2 + ".\n\nI suggest you brush your teeth with " + item3 + ".\n\nThen, rinse your mouth with " + item4 + ".\n\nIt's to get rid of the smell of " + item5 + " your breakfast will leave in your mouth.")