import random
x = random.randint(1, 15)
y = int(input("I'm thinking of a number from 1 and 15. Can you guess the number?"))

while y != x:
    y = int(input("Wrong number. Try again."))
    if y == x:
        print("Correct! The number was " + str(x) + ".")
